
#include<iostream>

int main(){
    std::cout<<"Totally legit computer program" << std::endl;
    return 0;
}